import 'package:flutter/material.dart';
import 'components/usuario.dart';

import 'dart:convert';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({Key? key}) : super(key: key);

  @override
  build(context) {
    return const MaterialApp(
      title: 'Lendo API de usuarios',
      home: UsuariosListView(),
    );
  }
}
