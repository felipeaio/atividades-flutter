import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import '../components/api.dart';

// Uma página para mostrar os detalhes de cada filme. Passamos o objeto
// do filme como parâmetro no constructor
class DetailPage extends StatelessWidget {
  final Usuario usuario;
  // ignore: use_key_in_widget_constructors
  const DetailPage(this.usuario);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(usuario.name),
      ),
      body: Container(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Center(
              child: Image(
                image: NetworkImage(
                  usuario.image,
                ),
              ),
            ),
            const Text("Email:"),
// Aqui a gente coloca um link clicável.
            Linkify(
              onOpen: (link) async {
                // ignore: deprecated_member_use
                if (await canLaunch(usuario.email)) {
                  // ignore: deprecated_member_use
                  await launch(usuario.email);
                } else {
                  throw 'Não foi possível abrir {$usuario.email}';
                }
              },
              text: usuario.email,
            ),
          ],
        ),
      ),
    );
  }
}
