import 'package:flutter/material.dart';
import 'dart:convert';
import '../../components/api.dart';
import '../details.dart';

// Vamos precisar de uma aplicação com estado
class UsuariosListView extends StatefulWidget {
  const UsuariosListView({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _UsuariosListViewState createState() => _UsuariosListViewState();
}

class _UsuariosListViewState extends State<UsuariosListView> {
  List<Usuario> usuario = List<Usuario>.empty(); // Lista dos filmes
  String search = "7618b0ce5550b7d4f05b"; // Plavra chave da pesquisa
// Construtor, atualiza com setState a lista de filmes.
  _UsuariosListViewState() {
    API.getUsuario(search).then((response) {
      setState(() {
        Iterable lista = json.decode(response.body); // Usamos um iterator
        usuario = lista.map((model) => Usuario.fromJson(model)).toList();
      });
    });
  }
// Método build sobrecarregado que vai construir nossa página
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Lista de Usuarios"),
      ),
// Aqui vem nossa lista
      body: ListView.builder(
        itemCount: usuario.length, // quantidade de elementos
// Os elementos da lista
        itemBuilder: (context, index) {
// Vai ser um item de lista tipo ListTile
          return ListTile(
// Uma imagem de avatar redondinho com a imagem do filme
            leading: CircleAvatar(
              backgroundImage: NetworkImage(
                usuario[index].image,
              ),
            ),
// No título é o nome do filme
            title: Text(
              usuario[index].name,
              style: const TextStyle(fontSize: 20.0, color: Colors.black),
            ),
// No subtítulo colocamos o link
            subtitle: Text(usuario[index].cpf),
// Ação de clicar
            onTap: () {
// Abrimos uma nova página, outra classe, que está no arquivo
// detail.dart. Veja que é um MaterialPageRote, tipo o
// MaterialApp, só que é só uma página nova.
              Navigator.push(
                context,
                // ignore: unnecessary_new
                new MaterialPageRoute(
                  builder: (context) => DetailPage(usuario[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
