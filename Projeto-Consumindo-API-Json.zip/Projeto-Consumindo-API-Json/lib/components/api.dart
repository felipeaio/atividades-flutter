// ignore_for_file: prefer_initializing_formals

import 'package:http/http.dart' as http;

// A URL da API
const baseUrl = "https://api.npoint.io/";

// Criamos a classe da nossa API. O nome você que escolhe. Fazemos aqui
// uma requisição get (como fizemos no react) e passamos a URL, mas usamos
// um Uri.parse pra transformar a string em uma URI.
class API {
  static Future getUsuario(search) async {
    var url = baseUrl + search;
    return await http.get(Uri.parse(url));
  }
}

// Criamos uma classe para representar os objetos que vão conter os filmes
// e colocamos só os campos que vamos usar.
class Usuario {
  late int id;
  late String name;
  late String cpf;
  late String email;
  late String image;

  Usuario(int id, String name, String cpf, String email, String image) {
    this.id = id;
    this.name = name;
    this.cpf = cpf;
    this.email = email;
    this.image = image;
  }
  Usuario.fromJson(Map json)
      : id = json['id'],
        name = json['name'],
        cpf = json['cpf'],
        email = json['email'],
        image = json['image'];
}
